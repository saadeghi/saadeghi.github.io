import{default as t}from"../components/error.svelte-4509af47.js";export{t as component};
