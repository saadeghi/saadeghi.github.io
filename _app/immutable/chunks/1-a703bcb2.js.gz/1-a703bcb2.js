import{default as t}from"../components/error.svelte-5b9b2560.js";export{t as component};
