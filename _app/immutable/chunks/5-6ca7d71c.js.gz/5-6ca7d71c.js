import{default as t}from"../components/pages/resume/_page.svelte-60ad074a.js";export{t as component};
