import{default as t}from"../components/pages/projects/_page.svelte-f3e6c2ad.js";export{t as component};
