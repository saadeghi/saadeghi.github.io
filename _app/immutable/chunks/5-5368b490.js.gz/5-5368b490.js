import{default as t}from"../components/pages/resume/_page.svelte-6f255326.js";export{t as component};
