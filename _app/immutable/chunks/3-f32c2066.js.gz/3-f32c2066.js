import{default as t}from"../components/pages/projects/_page.svelte-6e0f486c.js";export{t as component};
