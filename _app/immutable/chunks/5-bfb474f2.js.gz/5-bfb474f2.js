import{default as t}from"../components/pages/resume/_page.svelte-1d5eca5c.js";export{t as component};
