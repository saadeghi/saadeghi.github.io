import{default as t}from"../components/pages/resume/_page.svelte-6a04057c.js";export{t as component};
