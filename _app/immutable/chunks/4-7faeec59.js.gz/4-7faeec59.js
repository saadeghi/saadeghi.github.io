import{default as t}from"../components/pages/projects/_slug_/_page.svelte-034c9ef8.js";const e=!0;export{t as component,e as server};
