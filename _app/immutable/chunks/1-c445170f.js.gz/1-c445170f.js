import{default as t}from"../components/error.svelte-7bc1c55b.js";export{t as component};
