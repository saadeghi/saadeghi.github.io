import{default as r}from"../components/pages/_page.svelte-6aad4a86.js";import"./index-3c94462d.js";import"./stores-87bb3600.js";export{r as component};
