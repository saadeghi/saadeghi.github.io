import{default as m}from"../components/pages/_layout.svelte-8dce0414.js";import"./index-3c94462d.js";export{m as component};
