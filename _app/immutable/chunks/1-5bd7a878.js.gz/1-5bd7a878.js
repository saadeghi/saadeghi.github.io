import{default as t}from"../components/error.svelte-d2310047.js";export{t as component};
