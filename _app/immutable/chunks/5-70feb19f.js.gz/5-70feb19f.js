import{default as t}from"../components/pages/resume/_page.svelte-fa50b756.js";export{t as component};
