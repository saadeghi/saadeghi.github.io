import{default as t}from"../components/pages/projects/_page.svelte-ae41ae54.js";export{t as component};
