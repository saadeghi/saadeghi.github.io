const e=!0,r=!1,t=Object.freeze(Object.defineProperty({__proto__:null,prerender:!0,csr:!1},Symbol.toStringTag,{value:"Module"}));export{t as _,r as c,e as p};
