import{default as t}from"../components/pages/resume/_page.svelte-cb8b273a.js";export{t as component};
