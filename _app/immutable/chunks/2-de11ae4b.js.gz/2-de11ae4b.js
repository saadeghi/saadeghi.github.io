import{default as t}from"../components/pages/_page.svelte-8cc17df6.js";export{t as component};
