import{default as t}from"../components/pages/projects/_page.svelte-a7a09294.js";export{t as component};
