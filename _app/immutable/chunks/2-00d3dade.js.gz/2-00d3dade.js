import{default as r}from"../components/pages/_page.svelte-290311c3.js";import"./index-9b4f11f1.js";import"./stores-133e49df.js";export{r as component};
