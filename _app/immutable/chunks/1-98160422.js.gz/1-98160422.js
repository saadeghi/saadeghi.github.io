import{default as t}from"../components/error.svelte-63c522e4.js";export{t as component};
