import{default as t}from"../components/pages/projects/_page.svelte-ef56cbdf.js";export{t as component};
