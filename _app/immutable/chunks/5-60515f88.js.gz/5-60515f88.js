import{default as t}from"../components/pages/resume/_page.svelte-d12f451c.js";export{t as component};
