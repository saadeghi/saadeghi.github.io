import{default as t}from"../components/error.svelte-bfad104c.js";export{t as component};
