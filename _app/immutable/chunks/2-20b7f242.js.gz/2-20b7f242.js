import{default as t}from"../components/pages/_page.svelte-a9e21734.js";export{t as component};
