import{_ as r}from"./_layout-733a617e.js";import{default as t}from"../components/pages/_layout.svelte-da697964.js";export{t as component,r as universal};
