import{default as t}from"../components/pages/projects/_page.svelte-7479ba94.js";export{t as component};
