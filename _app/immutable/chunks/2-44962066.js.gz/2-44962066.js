import{default as t}from"../components/pages/_page.svelte-2c53b7fa.js";export{t as component};
