import{default as t}from"../components/pages/_page.svelte-c0f8d1e6.js";export{t as component};
