import{default as t}from"../components/pages/resume/_page.svelte-3b52b163.js";export{t as component};
