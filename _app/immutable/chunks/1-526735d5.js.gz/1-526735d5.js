import{default as r}from"../components/error.svelte-cbf39e1f.js";import"./index-9b4f11f1.js";import"./stores-133e49df.js";export{r as component};
