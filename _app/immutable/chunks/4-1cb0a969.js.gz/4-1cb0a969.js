import{default as t}from"../components/pages/projects/_slug_/_page.svelte-820bdcf6.js";const e=!0;export{t as component,e as server};
