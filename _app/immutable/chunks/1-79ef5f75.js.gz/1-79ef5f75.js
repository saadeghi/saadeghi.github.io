import{default as t}from"../components/error.svelte-3e2ec361.js";export{t as component};
