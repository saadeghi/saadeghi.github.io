import{default as t}from"../components/pages/_page.svelte-ed8e18b6.js";export{t as component};
