import{default as t}from"../components/pages/_page.svelte-cd90e6d3.js";export{t as component};
