import{default as t}from"../components/pages/_page.svelte-761a8161.js";export{t as component};
