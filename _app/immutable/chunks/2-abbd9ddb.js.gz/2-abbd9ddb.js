import{default as t}from"../components/pages/_page.svelte-53e03319.js";export{t as component};
