import{default as t}from"../components/error.svelte-bdc10782.js";export{t as component};
