import{default as m}from"../components/pages/_layout.svelte-3fc61b23.js";import"./index-3c94462d.js";export{m as component};
