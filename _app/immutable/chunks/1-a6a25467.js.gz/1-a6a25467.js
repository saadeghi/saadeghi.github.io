import{default as r}from"../components/error.svelte-8f61ac9a.js";import"./index-3c94462d.js";import"./stores-87bb3600.js";export{r as component};
