import{default as m}from"../components/pages/_layout.svelte-e5e3261a.js";import"./index-9b4f11f1.js";export{m as component};
