import{default as r}from"../components/pages/_page.svelte-22da4655.js";import"./index-3c94462d.js";import"./stores-87bb3600.js";export{r as component};
