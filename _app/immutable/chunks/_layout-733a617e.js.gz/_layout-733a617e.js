const r=!0,t=!1,e="always",s=Object.freeze(Object.defineProperty({__proto__:null,csr:!1,prerender:!0,trailingSlash:e},Symbol.toStringTag,{value:"Module"}));export{s as _,t as c,r as p,e as t};
