import{_ as r}from"./_layout-30fd11f6.js";import{default as t}from"../components/pages/_layout.svelte-e865c7ad.js";export{t as component,r as shared};
