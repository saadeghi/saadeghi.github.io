import{default as t}from"../components/pages/projects/_page.svelte-42b226dc.js";export{t as component};
