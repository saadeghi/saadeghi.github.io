import{default as t}from"../components/pages/projects/_page.svelte-3f876ac7.js";export{t as component};
