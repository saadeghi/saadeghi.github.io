import{default as t}from"../components/pages/resume/_page.svelte-8e2c8f7c.js";export{t as component};
