import{default as t}from"../components/error.svelte-4fa537dd.js";export{t as component};
