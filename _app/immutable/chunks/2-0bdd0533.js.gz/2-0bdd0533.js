import{default as t}from"../components/pages/_page.svelte-1fddb5d9.js";export{t as component};
