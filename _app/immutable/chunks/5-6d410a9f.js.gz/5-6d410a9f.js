import{default as t}from"../components/pages/resume/_page.svelte-457263d7.js";export{t as component};
