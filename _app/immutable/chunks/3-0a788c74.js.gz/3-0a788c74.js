import{default as t}from"../components/pages/projects/_page.svelte-caecb04d.js";export{t as component};
