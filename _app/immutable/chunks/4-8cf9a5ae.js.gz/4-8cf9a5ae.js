import{default as t}from"../components/pages/projects/_slug_/_page.svelte-0a5c7be0.js";export{t as component};
