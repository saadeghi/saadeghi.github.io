import{default as t}from"../components/pages/projects/_slug_/_page.svelte-bcb8e3f0.js";const e=!0;export{t as component,e as server};
