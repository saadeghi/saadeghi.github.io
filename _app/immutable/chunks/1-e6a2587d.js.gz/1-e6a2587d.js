import{default as t}from"../components/error.svelte-74185241.js";export{t as component};
