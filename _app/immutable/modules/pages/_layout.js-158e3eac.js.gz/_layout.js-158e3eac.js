import{c as p,p as s}from"../../chunks/_layout-30fd11f6.js";export{p as csr,s as prerender};
