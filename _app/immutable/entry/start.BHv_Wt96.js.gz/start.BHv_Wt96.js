import{a as t}from"../chunks/entry.CKLz325s.js";export{t as start};
