import{a as t}from"../chunks/entry.UZvq8w3q.js";export{t as start};
