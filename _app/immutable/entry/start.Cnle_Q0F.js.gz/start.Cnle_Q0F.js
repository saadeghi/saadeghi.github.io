import{a as t}from"../chunks/entry.mquyJ67F.js";export{t as start};
