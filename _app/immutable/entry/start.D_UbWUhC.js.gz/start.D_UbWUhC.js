import{a as t}from"../chunks/entry.Blk6bEPe.js";export{t as start};
