import{a as t}from"../chunks/entry.DG3s2YTs.js";export{t as start};
