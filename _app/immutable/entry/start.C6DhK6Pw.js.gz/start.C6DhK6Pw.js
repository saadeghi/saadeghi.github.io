import{a as t}from"../chunks/entry.DLlw4Nc0.js";export{t as start};
