import{a as t}from"../chunks/entry.D4LB3uMc.js";export{t as start};
