import{a as t}from"../chunks/entry.YFiq8R8Z.js";export{t as start};
